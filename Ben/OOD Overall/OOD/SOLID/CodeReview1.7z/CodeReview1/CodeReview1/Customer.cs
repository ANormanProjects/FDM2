﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeReview1
{
    public class Customer
    {
        public string id { get; set; }
        public Customer(string ID)
        {
            id = ID;
        }

        public void GoToShop(Store store)
        {

        }
     
    }
}
